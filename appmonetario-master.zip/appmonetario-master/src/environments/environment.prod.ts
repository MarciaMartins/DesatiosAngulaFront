export const environment = {
  production: true,
  API_URL: 'https://my-json-server.typicode.com/carolinebraz/appmonetario/',
};
